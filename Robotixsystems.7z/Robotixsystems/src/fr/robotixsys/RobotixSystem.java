package fr.robotixsys;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class RobotixSystem {
	
    public RobotixSystem() {
        users = new HashMap<>();
        robots = new HashMap<>();
        suppliers = new HashMap<>();
    }
    // Cas d'utilisation 1 : Cr�er un compte utilisateur
    public void createUserAccount(String name, String email, String password) {
        User newUser = new User(name, email, password);
        users.put(email, newUser);
    }
    // Cas d'utilisation 2 : Ajouter un robot
    public void addRobot(String name, String model, User owner) {
        Robot newRobot = new Robot(name, model, owner);
        robots.put(name, newRobot);
        owner.addRobot(newRobot);
    }

    // Cas d'utilisation 3 : Visualiser la flotte de robots
    public ArrayList<Robot> viewRobotFleet(User user) {
        return user.getRobots();
    }

    // Cas d'utilisation 4 : Surveiller l'�tat des robots
    public String getRobotStatus(Robot robot) {
        return robot.getStatus();
    }

    // Cas d'utilisation 5 : Commander des composants
    public void orderComponents(User user, Supplier supplier, ArrayList<Component> components) {
        supplier.processOrder(user, components);
    }

    // Cas d'utilisation 6 : Mettre � jour le firmware d'un robot
    public void updateRobotFirmware(Robot robot, String newFirmwareVersion) {
        robot.updateFirmware(newFirmwareVersion);
    }

    // Cas d'utilisation 7 : Diagnostiquer un robot
    public String diagnoseRobot(Robot robot) {
        return robot.runDiagnostics();
    }

    // Cas d'utilisation 8 : Programmer une t�che pour un robot
    public void scheduleRobotTask(Robot robot, Task task) {
        robot.addTask(task);
    }

    // Cas d'utilisation 9 : Consulter les statistiques d'utilisation
    public Map<Robot, Integer> getUsageStatistics(User user) {
        Map<Robot, Integer> statistics = new HashMap<>();
        for (Robot robot : user.getRobots()) {
            statistics.put(robot, robot.getUsageHours());
        }
        return statistics;
    }

    // Cas d'utilisation 10 : Contacter le support technique
    public void requestTechnicalSupport(User user, String issue) {
        // Envoyer la demande de support au service apr�s-vente
    }
}
