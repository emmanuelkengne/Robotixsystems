package fr.robotixsys;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("10 fonctionnalit�s identifi�es dans vos cas d'utilisation");
	}

}
